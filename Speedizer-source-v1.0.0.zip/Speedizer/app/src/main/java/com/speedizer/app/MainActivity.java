package com.speedizer.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Speedizer dashboard: RAM ring, boost button, live stats and quick theme switch.
 */
public class MainActivity extends android.app.Activity {

    private RamRingView ring;
    private Button btnBoost;
    private ImageButton btnTheme, btnSettings;
    private TextView tvService, tvRam, tvBg, tvFreed, tvLast;
    private View dotService;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean boosting = false;

    private final BroadcastReceiver ramReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (BoostService.ACTION_RAM_UPDATE.equals(intent.getAction())) {
                int pct = intent.getIntExtra(BoostService.EXTRA_PCT, -1);
                int processes = intent.getIntExtra(BoostService.EXTRA_PROCESSES, -1);
                long freed = intent.getLongExtra(BoostService.EXTRA_FREED, -1);
                if (pct >= 0 && !boosting) {
                    BoostEngine.RamInfo info = BoostEngine.ramInfo(MainActivity.this);
                    ring.setValue(pct, Fa.percent(pct), Fa.usedOfTotal(info.used, info.total));
                }
                if (processes >= 0) tvBg.setText(Fa.num(processes));
                if (freed >= 0) tvFreed.setText(Fa.fileSize(freed));
                refreshServiceStatus();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemePrefs.themeRes(ThemePrefs.isDark(this)));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fonts.applyAll(findViewById(android.R.id.content));

        ring = findViewById(R.id.ring);
        btnBoost = findViewById(R.id.btnBoost);
        btnTheme = findViewById(R.id.btnTheme);
        btnSettings = findViewById(R.id.btnSettings);
        tvService = findViewById(R.id.tvService);
        tvRam = findViewById(R.id.tvRam);
        tvBg = findViewById(R.id.tvBg);
        tvFreed = findViewById(R.id.tvFreed);
        tvLast = findViewById(R.id.tvLast);
        dotService = findViewById(R.id.dotService);

        btnBoost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBoost();
            }
        });

        btnTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean newDark = !ThemePrefs.isDark(MainActivity.this);
                ThemePrefs.setDark(MainActivity.this, newDark);
                recreate();
            }
        });

        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        findViewById(R.id.chipStatus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        requestNotificationPermissionIfNeeded();
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(ramReceiver, new IntentFilter(BoostService.ACTION_RAM_UPDATE));
        BoostService.start(this);          // keep the monitor alive whenever the app is open
        CleanAlarmReceiver.schedule(this); // and make sure the backup alarm is set
        refreshAll();
        refreshThemeIcon();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(ramReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    // ---------------- UI refresh ----------------

    private void refreshThemeIcon() {
        boolean dark = ThemePrefs.isDark(this);
        btnTheme.setImageResource(dark ? R.drawable.ic_sun : R.drawable.ic_moon);
    }

    private void refreshAll() {
        BoostEngine.RamInfo info = BoostEngine.ramInfo(this);
        ring.setValue(info.percent, Fa.percent(info.percent),
                Fa.usedOfTotal(info.used, info.total));
        tvRam.setText(Fa.usedOfTotal(info.used, info.total));
        tvBg.setText(Fa.num(BoostEngine.activeProcessCount(this)));
        tvFreed.setText(Fa.fileSize(ThemePrefs.freedToday(this)));
        tvLast.setText(formatLastClean(ThemePrefs.lastClean(this)));
        refreshServiceStatus();
    }

    private void refreshServiceStatus() {
        boolean on = BoostService.isRunning();
        tvService.setText(on ? R.string.service_status_on : R.string.service_status_off);
        dotService.getBackground().setTint(getColor(on ? R.color.good_green : R.color.bad_red));
    }

    private String formatLastClean(long ts) {
        if (ts <= 0) return getString(R.string.never);
        String t = new SimpleDateFormat("HH:mm", Locale.US).format(new Date(ts));
        String d = new SimpleDateFormat("MM/dd", Locale.US).format(new Date(ts));
        return Fa.num(t) + "  (" + Fa.num(d) + ")";
    }

    // ---------------- Boost flow ----------------

    private void startBoost() {
        if (boosting) return;
        boosting = true;
        btnBoost.setEnabled(false);
        btnBoost.setText(R.string.boost_running);
        btnBoost.setAlpha(0.85f);
        ring.setIndeterminate(true);

        executor.execute(new Runnable() {
            @Override
            public void run() {
                final BoostEngine.BoostResult r = BoostEngine.boost(MainActivity.this);
                ThemePrefs.addFreed(MainActivity.this, r.freed);
                ThemePrefs.setLastClean(MainActivity.this, System.currentTimeMillis());
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        showBoostResult(r);
                    }
                });
            }
        });
    }

    private void showBoostResult(BoostEngine.BoostResult r) {
        boosting = false;
        ring.setIndeterminate(false);
        btnBoost.setEnabled(true);
        btnBoost.setText(R.string.boost_button);
        btnBoost.setAlpha(1f);

        BoostEngine.RamInfo now = BoostEngine.ramInfo(this);
        ring.setValue(now.percent, Fa.percent(now.percent),
                Fa.usedOfTotal(now.used, now.total));
        tvRam.setText(Fa.usedOfTotal(now.used, now.total));
        tvFreed.setText(Fa.fileSize(ThemePrefs.freedToday(this)));
        tvLast.setText(formatLastClean(System.currentTimeMillis()));
        refreshServiceStatus();

        String msg = getString(R.string.clean_done_msg,
                Fa.fileSize(r.freed),
                Fa.percent(r.before.percent),
                Fa.percent(r.after.percent))
                + "\n\n" + getString(R.string.clean_done_apps, r.cleanedApps);

        new AlertDialog.Builder(this, ThemePrefs.dialogThemeRes(ThemePrefs.isDark(this)))
                .setTitle(R.string.clean_done_title)
                .setMessage(msg)
                .setIcon(R.drawable.ic_logo)
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    // ---------------- Permissions ----------------

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 7) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (!granted) {
                Toast.makeText(this, R.string.notification_perm_note, Toast.LENGTH_LONG).show();
            }
        }
    }
}
