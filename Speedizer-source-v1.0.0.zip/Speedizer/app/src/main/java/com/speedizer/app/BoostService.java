package com.speedizer.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Foreground service that continuously monitors RAM usage, refreshes the
 * persistent notification, and automatically cleans the background every
 * N minutes (or when memory pressure becomes high).
 */
public class BoostService extends Service {

    public static final String ACTION_START = "com.speedizer.app.action.START";
    public static final String ACTION_STOP = "com.speedizer.app.action.STOP";
    public static final String ACTION_BOOST_NOW = "com.speedizer.app.action.BOOST_NOW";
    public static final String ACTION_RAM_UPDATE = "com.speedizer.app.RAM_UPDATE";

    public static final String EXTRA_PCT = "pct";
    public static final String EXTRA_FREED = "freed";
    public static final String EXTRA_PROCESSES = "processes";
    public static final String EXTRA_CLEANED = "cleaned";

    private static final String CHANNEL_ID = "speedizer_monitor";
    private static final int NOTIF_ID = 42;
    private static final long TICK_MS = 30_000L;          // monitor tick: 30 s
    private static final long EMERGENCY_MIN_GAP = 5 * 60_000L;

    private static volatile boolean running = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private NotificationManager nm;
    private volatile boolean boosting = false;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            BoostEngine.RamInfo info = BoostEngine.ramInfo(BoostService.this);
            maybeAutoBoost(info);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification(info));
            broadcast(info, null);
            CleanAlarmReceiver.schedule(BoostService.this); // keep the backup alarm fresh
            handler.postDelayed(this, TICK_MS);
        }
    };

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
        BoostEngine.RamInfo info = BoostEngine.ramInfo(this);
        startForeground(NOTIF_ID, buildNotification(info));
        handler.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_BOOST_NOW.equals(action)) {
            boostNow();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------- Auto clean ----------------

    private void maybeAutoBoost(BoostEngine.RamInfo info) {
        if (!ThemePrefs.autoClean(this) || boosting) return;

        long now = System.currentTimeMillis();
        long interval = ThemePrefs.intervalMin(this) * 60_000L;
        long last = ThemePrefs.lastClean(this);
        boolean dueByTime = last == 0 || (now - last) >= interval;
        boolean emergency = info.percent >= 85 && (now - last) >= EMERGENCY_MIN_GAP;

        if (dueByTime || emergency) {
            boostNow();
        }
    }

    private void boostNow() {
        if (boosting) return;
        boosting = true;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                BoostEngine.BoostResult r = BoostEngine.boost(BoostService.this);
                ThemePrefs.addFreed(BoostService.this, r.freed);
                ThemePrefs.setLastClean(BoostService.this, System.currentTimeMillis());

                BoostEngine.RamInfo after = BoostEngine.ramInfo(BoostService.this);
                if (nm != null) {
                    Notification n = buildNotification(after);
                    if (r.freed > 0) {
                        Notification.Builder b = riff(n);
                        b.setContentText(getString(R.string.notif_autoclean,
                                Fa.fileSize(r.freed)));
                        n = b.build();
                    }
                    nm.notify(NOTIF_ID, n);
                }
                broadcast(after, r);
                boosting = false;
            }
        });
    }

    // ---------------- Notification ----------------

    private Notification buildNotification(BoostEngine.RamInfo info) {
        Notification.Builder b = riff(null);
        b.setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text, Fa.percent(info.percent)))
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        return b.build();
    }

    private Notification.Builder riff(Notification reuse) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pOpen = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent boost = new Intent(this, BoostService.class).setAction(ACTION_BOOST_NOW);
        PendingIntent pBoost = PendingIntent.getService(this, 2, boost,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = reuse != null
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this, CHANNEL_ID);
        b.setSmallIcon(R.drawable.ic_stat_bolt)
                .setContentIntent(pOpen)
                .addAction(new Notification.Action.Builder(
                        null, getString(R.string.notif_action_boost), pBoost).build());

        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                    getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription(getString(R.string.notif_channel_desc));
            ch.setShowBadge(false);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    // ---------------- Broadcast to UI ----------------

    private void broadcast(BoostEngine.RamInfo info, BoostEngine.BoostResult result) {
        Intent i = new Intent(ACTION_RAM_UPDATE).setPackage(getPackageName());
        i.putExtra(EXTRA_PCT, info.percent);
        i.putExtra(EXTRA_PROCESSES, BoostEngine.activeProcessCount(this));
        i.putExtra(EXTRA_FREED, ThemePrefs.freedToday(this));
        i.putExtra(EXTRA_CLEANED, result != null ? result.cleanedApps : -1);
        sendBroadcast(i);
    }

    /** Convenience for receivers/activities. */
    public static void start(Context ctx) {
        Intent i = new Intent(ctx, BoostService.class).setAction(ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(i);
            } else {
                ctx.startService(i);
            }
        } catch (Throwable ignored) {
        }
    }
}
