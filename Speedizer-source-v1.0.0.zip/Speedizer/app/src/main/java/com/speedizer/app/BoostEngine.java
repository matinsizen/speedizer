package com.speedizer.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Memory inspection & RAM boosting engine.
 *
 * Uses the framework APIs available to normal (non-root) apps:
 *  - ActivityManager.MemoryInfo for usage stats
 *  - ActivityManager.killBackgroundProcesses() for freeing memory
 */
public final class BoostEngine {

    private BoostEngine() {}

    // ---------------- Data holders ----------------

    public static class RamInfo {
        public final long total;
        public final long avail;
        public final long used;
        public final int percent;

        RamInfo(long total, long avail, long used, int percent) {
            this.total = total;
            this.avail = avail;
            this.used = used;
            this.percent = percent;
        }
    }

    public static class BoostResult {
        public final RamInfo before;
        public final RamInfo after;
        public final long freed;
        public final int cleanedApps;

        BoostResult(RamInfo before, RamInfo after, long freed, int cleanedApps) {
            this.before = before;
            this.after = after;
            this.freed = freed;
            this.cleanedApps = cleanedApps;
        }
    }

    // ---------------- Inspection ----------------

    public static RamInfo ramInfo(Context ctx) {
        ActivityManager am = (ActivityManager) ctx.getApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(mi);
        long used = mi.totalMem - mi.availMem;
        int pct = mi.totalMem > 0 ? (int) Math.round(used * 100.0 / mi.totalMem) : 0;
        return new RamInfo(mi.totalMem, mi.availMem, used, Math.max(0, Math.min(100, pct)));
    }

    public static int activeProcessCount(Context ctx) {
        try {
            ActivityManager am = (ActivityManager) ctx.getApplicationContext()
                    .getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();
            return list == null ? 0 : list.size();
        } catch (Throwable t) {
            return 0;
        }
    }

    // ---------------- Target collection ----------------

    /** Packages that must never be killed for the phone to stay usable. */
    public static Set<String> protectedPackages(Context ctx) {
        Set<String> keep = new HashSet<>();
        keep.add(ctx.getPackageName());
        keep.add("com.android.systemui");
        keep.add("com.android.phone");
        keep.add("com.android.inputsms"); // legacy guard
        keep.add("com.android.settings");
        keep.add("com.android.nfc");
        keep.add("com.android.bluetooth");
        keep.add("com.android.providers.telephony");
        keep.add("com.android.providers.contacts");
        keep.add("com.android.providers.media");

        PackageManager pm = ctx.getPackageManager();
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> launchers = pm.queryIntentActivities(home, 0);
            for (ResolveInfo r : launchers) {
                if (r != null && r.activityInfo != null) {
                    keep.add(r.activityInfo.packageName);
                }
            }
        } catch (Throwable ignored) {
        }
        return keep;
    }

    /** All installed packages that are safe to attempt cleaning. */
    public static List<String> collectTargets(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        Set<String> keep = protectedPackages(ctx);
        List<String> out = new ArrayList<>();
        try {
            List<ApplicationInfo> all = pm.getInstalledApplications(0);
            for (ApplicationInfo ai : all) {
                String pkg = ai.packageName;
                if (pkg == null || keep.contains(pkg)) continue;
                out.add(pkg);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    // ---------------- Boost ----------------

    /**
     * Runs a full RAM boost: kills background processes of every cleanable
     * package, waits for the system to reclaim memory and measures the result.
     * Must be called on a background thread.
     */
    public static BoostResult boost(Context ctx) {
        Context app = ctx.getApplicationContext();
        RamInfo before = ramInfo(app);
        ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);

        List<String> targets = collectTargets(app);
        int attempts = 0;
        if (am != null) {
            for (String pkg : targets) {
                try {
                    am.killBackgroundProcesses(pkg);
                    attempts++;
                } catch (Throwable ignored) {
                }
            }
        }

        // Give the OS a moment to actually reclaim freed pages.
        try {
            Thread.sleep(900);
        } catch (InterruptedException ignored) {
        }

        RamInfo after = ramInfo(app);
        long freed = after.avail - before.avail;
        if (freed < 0) freed = 0;
        return new BoostResult(before, after, freed, attempts);
    }
}
