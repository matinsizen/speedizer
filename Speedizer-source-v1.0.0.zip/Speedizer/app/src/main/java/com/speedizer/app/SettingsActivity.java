package com.speedizer.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

/**
 * Settings: theme switch (blue&white / blue&black), auto-clean interval,
 * start on boot and about section.
 */
public class SettingsActivity extends Activity {

    private Switch swTheme, swAuto, swBoot;
    private RadioGroup rgInterval;
    private RadioButton rb15, rb30, rb60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemePrefs.themeRes(ThemePrefs.isDark(this)));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Fonts.applyAll(findViewById(android.R.id.content));

        ImageButton btnBack = findViewById(R.id.btnBack);
        swTheme = findViewById(R.id.swTheme);
        swAuto = findViewById(R.id.swAuto);
        swBoot = findViewById(R.id.swBoot);
        rgInterval = findViewById(R.id.rgInterval);
        rb15 = findViewById(R.id.rb15);
        rb30 = findViewById(R.id.rb30);
        rb60 = findViewById(R.id.rb60);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // ---- current values ----
        boolean dark = ThemePrefs.isDark(this);
        boolean auto = ThemePrefs.autoClean(this);
        int interval = ThemePrefs.intervalMin(this);

        swTheme.setChecked(dark);
        swAuto.setChecked(auto);
        swBoot.setChecked(ThemePrefs.startOnBoot(this));
        if (interval == 30) rb30.setChecked(true);
        else if (interval == 60) rb60.setChecked(true);
        else rb15.setChecked(true);
        setIntervalEnabled(auto);

        // ---- listeners ----
        swTheme.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ThemePrefs.setDark(SettingsActivity.this, isChecked);
                recreate();
            }
        });

        swAuto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ThemePrefs.setAutoClean(SettingsActivity.this, isChecked);
                setIntervalEnabled(isChecked);
                if (isChecked) {
                    BoostService.start(SettingsActivity.this);
                    CleanAlarmReceiver.schedule(SettingsActivity.this);
                }
            }
        });

        swBoot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ThemePrefs.setStartOnBoot(SettingsActivity.this, isChecked);
            }
        });

        rgInterval.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int minutes = 15;
                if (checkedId == R.id.rb30) minutes = 30;
                else if (checkedId == R.id.rb60) minutes = 60;
                ThemePrefs.setIntervalMin(SettingsActivity.this, minutes);
                CleanAlarmReceiver.schedule(SettingsActivity.this);
            }
        });
    }

    private void setIntervalEnabled(boolean enabled) {
        for (RadioButton rb : new RadioButton[]{rb15, rb30, rb60}) {
            rb.setEnabled(enabled);
            rb.setAlpha(enabled ? 1f : 0.45f);
        }
    }
}
