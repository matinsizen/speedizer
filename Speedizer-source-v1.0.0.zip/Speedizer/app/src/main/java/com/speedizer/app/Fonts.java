package com.speedizer.app;

import android.graphics.Typeface;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

/**
 * Applies the bundled Vazirmatn Persian typeface on API 26+ devices.
 * On older devices the system Persian font (Noto Naskh Arabic) is used,
 * because res/font resources are only resolvable from API 26.
 */
public final class Fonts {

    private static Typeface regular;
    private static Typeface bold;

    private Fonts() {}

    public static void applyAll(View root) {
        if (Build.VERSION.SDK_INT < 26 || root == null) return;
        try {
            if (regular == null) {
                regular = root.getResources().getFont(R.font.vazirmatn);
                bold = root.getResources().getFont(R.font.vazirmatn_bold);
            }
            walk(root);
        } catch (Throwable ignored) {
            // Font resources unavailable — fall back to system font.
        }
    }

    private static void walk(View v) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            boolean wantBold = (tv.getTypeface() != null && tv.getTypeface().isBold())
                    || tv instanceof Button;
            tv.setTypeface(wantBold && bold != null ? bold : regular);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                walk(g.getChildAt(i));
            }
        }
    }

    public static Typeface bold(View host) {
        if (bold == null && Build.VERSION.SDK_INT >= 26) {
            try {
                bold = host.getResources().getFont(R.font.vazirmatn_bold);
            } catch (Throwable ignored) {}
        }
        return bold;
    }

    public static Typeface regular(View host) {
        if (regular == null && Build.VERSION.SDK_INT >= 26) {
            try {
                regular = host.getResources().getFont(R.font.vazirmatn);
            } catch (Throwable ignored) {}
        }
        return regular;
    }
}
