package com.speedizer.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Restarts the monitoring service after the phone boots, when the user
 * enabled "start on boot".
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (action == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !"android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            return;
        }
        if (ThemePrefs.autoClean(context) || ThemePrefs.startOnBoot(context)) {
            BoostService.start(context);
            CleanAlarmReceiver.schedule(context);
        }
    }
}
