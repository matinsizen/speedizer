package com.speedizer.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Central storage for theme, auto-clean settings and daily freed-memory statistics.
 */
public final class ThemePrefs {

    private static final String PREFS = "speedizer_prefs";

    public static final String KEY_DARK = "dark_theme";       // false = light (blue & white)
    public static final String KEY_AUTO = "auto_clean";       // background auto cleaning
    public static final String KEY_BOOT = "start_on_boot";    // restart service after boot
    public static final String KEY_INTERVAL = "interval_min"; // 15 / 30 / 60
    public static final String KEY_FREED = "freed_bytes";     // bytes freed today
    public static final String KEY_FREED_DAY = "freed_day";   // yyyy-MM-dd of the counter
    public static final String KEY_LAST_CLEAN = "last_clean"; // timestamp

    private ThemePrefs() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------------- Theme ----------------

    public static boolean isDark(Context c) {
        return p(c).getBoolean(KEY_DARK, false);
    }

    public static void setDark(Context c, boolean dark) {
        p(c).edit().putBoolean(KEY_DARK, dark).apply();
    }

    /** Applies the matching activity theme. Call BEFORE super.onCreate(). */
    public static void applyTheme(Context c) {
        // Implemented in activities via setTheme(); kept for clarity.
    }

    public static int themeRes(boolean dark) {
        return dark ? R.style.Theme_Speedizer_Dark : R.style.Theme_Speedizer;
    }

    public static int dialogThemeRes(boolean dark) {
        return dark ? R.style.Theme_Speedizer_Dialog_Dark : R.style.Theme_Speedizer_Dialog;
    }

    // ---------------- Toggles ----------------

    public static boolean autoClean(Context c) {
        return p(c).getBoolean(KEY_AUTO, true);
    }

    public static void setAutoClean(Context c, boolean v) {
        p(c).edit().putBoolean(KEY_AUTO, v).apply();
    }

    public static boolean startOnBoot(Context c) {
        return p(c).getBoolean(KEY_BOOT, true);
    }

    public static void setStartOnBoot(Context c, boolean v) {
        p(c).edit().putBoolean(KEY_BOOT, v).apply();
    }

    public static int intervalMin(Context c) {
        return p(c).getInt(KEY_INTERVAL, 15);
    }

    public static void setIntervalMin(Context c, int v) {
        p(c).edit().putInt(KEY_INTERVAL, v).apply();
    }

    // ---------------- Stats ----------------

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public static long freedToday(Context c) {
        SharedPreferences sp = p(c);
        if (!today().equals(sp.getString(KEY_FREED_DAY, ""))) {
            return 0L;
        }
        return sp.getLong(KEY_FREED, 0L);
    }

    public static void addFreed(Context c, long bytes) {
        if (bytes <= 0) return;
        SharedPreferences sp = p(c);
        String day = today();
        long cur = day.equals(sp.getString(KEY_FREED_DAY, "")) ? sp.getLong(KEY_FREED, 0L) : 0L;
        sp.edit().putString(KEY_FREED_DAY, day).putLong(KEY_FREED, cur + bytes).apply();
    }

    public static long lastClean(Context c) {
        return p(c).getLong(KEY_LAST_CLEAN, 0L);
    }

    public static void setLastClean(Context c, long ts) {
        p(c).edit().putLong(KEY_LAST_CLEAN, ts).apply();
    }
}
