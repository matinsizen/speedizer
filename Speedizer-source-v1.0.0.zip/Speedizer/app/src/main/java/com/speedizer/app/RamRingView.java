package com.speedizer.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;

/**
 * Circular RAM usage ring with animated progress and an indeterminate mode
 * used while boosting.
 */
public class RamRingView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bottomPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();

    private float value = 0f;        // displayed 0..100
    private float target = 0f;       // requested 0..100
    private boolean indeterminate = false;
    private float indetAngle = 0f;
    private long lastFrame = 0;

    private String centerText = "";
    private String subText = "";
    private String bottomText = "";

    private int colorTrack;
    private int colorStart;
    private int colorEnd;
    private int colorText;
    private int colorSub;

    private ValueAnimator animator;

    public RamRingView(Context context) {
        super(context);
        init();
    }

    public RamRingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RamRingView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        int[] attrs = {R.attr.colorRingTrack, R.attr.colorAccent, R.attr.colorTextMain, R.attr.colorTextSub};
        android.content.res.TypedArray ta = getContext().obtainStyledAttributes(attrs);
        colorTrack = ta.getColor(0, 0xFFE1ECF8);
        int accent = ta.getColor(1, 0xFF2196F3);
        colorText = ta.getColor(2, 0xFF0F2440);
        colorSub = ta.getColor(3, 0xFF61788F);
        ta.recycle();

        // Gradient from a light blue to the deep accent blue.
        colorStart = shift(accent, 1.35f);
        colorEnd = shift(accent, 0.72f);

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setColor(colorTrack);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(colorText);
        textPaint.setTypeface(Fonts.bold(this));

        subPaint.setTextAlign(Paint.Align.CENTER);
        subPaint.setColor(colorSub);
        subPaint.setTypeface(Fonts.regular(this));

        bottomPaint.setTextAlign(Paint.Align.CENTER);
        bottomPaint.setColor(colorSub);
        bottomPaint.setTypeface(Fonts.regular(this));
    }

    private static int shift(int color, float factor) {
        int r = Math.min(255, Math.round(((color >> 16) & 0xFF) * factor));
        int g = Math.min(255, Math.round(((color >> 8) & 0xFF) * factor));
        int b = Math.min(255, Math.round((color & 0xFF) * factor));
        return (0xFF << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, ow);
        int size = Math.min(w, h);
        float stroke = size * 0.075f;
        trackPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeWidth(stroke);

        float half = size * 0.5f;
        SweepGradient sweep = new SweepGradient(half, half,
                new int[]{colorStart, accentColor(), colorEnd, colorStart},
                new float[]{0f, 0.42f, 0.75f, 1f});
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.setRotate(-90, half, half);
        sweep.setLocalMatrix(m);
        progressPaint.setShader(sweep);
    }

    private int accentColor() {
        return (colorStart + colorEnd) / 2;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        int size = Math.min(w, h);
        float inset = size * 0.0375f + size * 0.02f;
        arcRect.set(inset, inset, w - inset, h - inset);

        canvas.drawArc(arcRect, 0, 360, false, trackPaint);

        if (indeterminate) {
            long now = AnimationUtils.currentAnimationTimeMillis();
            if (lastFrame != 0) {
                indetAngle += (now - lastFrame) * 0.28f;
                if (indetAngle >= 360f) indetAngle -= 360f;
            }
            lastFrame = now;
            canvas.drawArc(arcRect, indetAngle, 95f, false, progressPaint);
            postInvalidateOnAnimation();
        } else {
            lastFrame = 0;
            if (value > 0.5f) {
                canvas.drawArc(arcRect, -90, value * 3.6f, false, progressPaint);
            }
        }

        float cx = w / 2f;
        float cy = h / 2f;

        float bigSize = size * 0.20f;
        textPaint.setTextSize(bigSize);
        canvas.drawText(centerText, cx, centeredY(cy - size * 0.075f, textPaint), textPaint);

        subPaint.setTextSize(size * 0.072f);
        canvas.drawText(subText, cx, centeredY(cy + size * 0.085f, subPaint), subPaint);

        bottomPaint.setTextSize(size * 0.062f);
        canvas.drawText(bottomText, cx, centeredY(cy + size * 0.185f, bottomPaint), bottomPaint);
    }

    private static float centeredY(float anchor, Paint p) {
        Paint.FontMetrics fm = p.getFontMetrics();
        return anchor - (fm.ascent + fm.descent) / 2f;
    }

    // ---------------- Public API ----------------

    public void setValue(float pct, String center, String bottom) {
        this.target = Math.max(0f, Math.min(100f, pct));
        this.centerText = center == null ? "" : center;
        this.bottomText = bottom == null ? "" : bottom;
        this.subText = getResources().getString(R.string.ram_usage);
        animateTo(target);
    }

    public void setTextOnly(String center, String bottom) {
        this.centerText = center == null ? "" : center;
        this.bottomText = bottom == null ? "" : bottom;
        invalidate();
    }

    public void setIndeterminate(boolean active) {
        if (this.indeterminate == active) return;
        this.indeterminate = active;
        this.lastFrame = 0;
        if (active && animator != null) animator.cancel();
        invalidate();
    }

    private void animateTo(float to) {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        if (Math.abs(to - value) < 0.5f) {
            value = to;
            invalidate();
            return;
        }
        animator = ValueAnimator.ofFloat(value, to);
        animator.setDuration(850);
        animator.setInterpolator(new DecelerateInterpolator(1.6f));
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                value = (float) a.getAnimatedValue();
                invalidate();
            }
        });
        animator.start();
    }
}
