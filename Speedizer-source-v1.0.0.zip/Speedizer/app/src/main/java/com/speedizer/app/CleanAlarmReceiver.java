package com.speedizer.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Backup alarm receiver. The foreground service handles periodic cleaning
 * itself; this alarm restarts the service if the system ever kills it,
 * keeping the "every N minutes" promise alive even after process death.
 */
public class CleanAlarmReceiver extends BroadcastReceiver {

    private static final int REQUEST_CODE = 1001;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!ThemePrefs.autoClean(context)) return;
        if (BoostService.isRunning()) return;
        BoostService.start(context);
    }

    public static void schedule(Context ctx) {
        Context app = ctx.getApplicationContext();
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(app, CleanAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(app, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long interval = ThemePrefs.intervalMin(app) * 60_000L;
        long trigger = System.currentTimeMillis() + interval;
        try {
            // Non-exact alarms need no special permission on any supported API level.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        } catch (Throwable ignored) {
        }
    }

    public static void cancel(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getApplicationContext()
                .getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, CleanAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }
}
