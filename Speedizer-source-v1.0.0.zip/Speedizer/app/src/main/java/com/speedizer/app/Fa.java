package com.speedizer.app;

import java.util.Locale;

/**
 * Utilities for Persian digits and human-readable sizes.
 */
public final class Fa {

    private static final char[] FA_DIGITS = {'۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'};

    private Fa() {}

    /** Converts western digits to Persian digits. */
    public static String num(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (char c : s.toCharArray()) {
            if (c >= '0' && c <= '9') {
                b.append(FA_DIGITS[c - '0']);
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }

    public static String num(int v) {
        return num(String.valueOf(v));
    }

    public static String num(long v) {
        return num(String.valueOf(v));
    }

    /** Persian percent string like ۶۳٪ */
    public static String percent(int p) {
        return num(p) + "٪";
    }

    /** Formats byte count as گیگابایت / مگابایت with Persian digits. */
    public static String fileSize(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1.0) {
            return num(String.format(Locale.US, "%.1f", gb).replace('.', '٫')) + " گیگابایت";
        }
        double mb = bytes / (1024.0 * 1024.0);
        if (mb >= 1.0) {
            return num((long) Math.round(mb)) + " مگابایت";
        }
        return num((long) Math.max(0, bytes / 1024.0)) + " کیلوبایت";
    }

    /** Short size like "۲٫۳ از ۴ گیگ" for the RAM card. */
    public static String usedOfTotal(long used, long total) {
        double uGb = used / (1024.0 * 1024.0 * 1024.0);
        double tGb = total / (1024.0 * 1024.0 * 1024.0);
        return num(String.format(Locale.US, "%.1f از %.1f گیگ", uGb, tGb).replace('.', '٫'));
    }
}
