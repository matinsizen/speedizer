# Speedizer ProGuard rules (minification is disabled by default)
